/*Dados dos processos*/
typedef struct info data;
struct info
{
	char nome[30];
	int t0, dt, deadline,tf, id, idAnterior, idSeguinte, tr, tquantum;
};
