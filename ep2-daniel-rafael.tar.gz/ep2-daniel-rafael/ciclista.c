#include <stdlib.h>
#include "ciclista.h"

Ciclistas init(int Vo, int quebrou, int volta, int id)
{
	Ciclistas a;
	a.Vo = Vo;
	a.quebrou = quebrou;
	a.volta = volta;
	a.id = id;
	a.distancia = 0.0;
	a.pos_anterior = 0.0;
	a.eliminado = 0;
	a.noventa = 0;
	a.tf = 0;
	return a;
}
