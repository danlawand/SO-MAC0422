#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include "string.h"
#include "math.h"
#include "ciclista.h"

int n;
int d;
int altera; //round
pthread_barrier_t barrier[2];
pthread_t *ciclista;
Ciclistas *ciclistas;
Ciclistas *ultimo, primeiro;
int pos = 0;
int ultimoVazio = 1;
int idUltimo;
pthread_mutex_t sem, sem1, sem2, sem3, sem4;
int num;
int eliminado = 0;
int *rodada;
int tempo = 0;
int **pista;
int idEliminado = -1;
int idQuebrado;
int quebrado = 0;
int quebrou = 0;
int primeiroQuebrado = -1;
int ms;
int indice_q = 0;
int debug = 0;
Ciclistas *ranking, *quebrados;
int indice_r = 0;

struct timespec ts;

void dump_pista()
{
	for (int i = 0; i < d; ++i)
	{
		for (int j = 0; j < 10; ++j)
		{
			if (pista[i][j] != -1) {
				printf(" 0%d ",pista[i][j] );
			} else {
				printf(" %d ",pista[i][j] );
			}
		}
		printf("\n");
	}
}


int rand_range(int lower, int upper)
{
	return ( rand() % (upper - lower + 1) ) + lower;
}

void ocupa_pista()
{
	int i, j;
	int k = 0;
	int id = 0;
	float dist = 0.0;
	int ocupadas[5];   //vetor que contem a informacao de quais faixar serao ocupadas no inicio
	int numbers[10];
	for(i = 0; i < 10; i++) numbers[i] = 0;
	for(i = 0; i < 5; i++)
	{
		int rng = rand_range(0,9);
		if(numbers[rng] == 0)
		{
			ocupadas[i] = rng;
			numbers[rng] = 1;
		}
		else
			i--;
	}
  k = 0;
	for(i = 0; i < d && k < n; i++)
	{
		for(j = 0; j < 5 && k < n; j++,k++,id++)
		{
			pista[i][ocupadas[j]] = id;
	    ciclistas[id].faixa = ocupadas[j];
	    ciclistas[id].distancia = dist;
  	}
    dist+=1.0;
  }
}

void calculo_velocidade(int id)
{
	if (ciclistas[id].volta == (n-1)*2 - 2 - (indice_q*2)) {
		if (!ciclistas[id].noventa) {
			if (rand_range(0, 100) < 10) {
				ciclistas[id].velocidadeAnterior = ciclistas[id].velocidadeAtual;
				ciclistas[id].velocidadeAtual = 90;
				ms = 20;
				ciclistas[id].noventa = 1;
			}
		}
	}
  if (ciclistas[id].volta == 0) {
    ciclistas[id].velocidadeAtual = 30;
	} else if (!ciclistas[id].noventa) {
    if (ciclistas[id].velocidadeAtual == 30) {
      if(rand_range(1,100) < 80) {
        ciclistas[id].velocidadeAnterior = ciclistas[id].velocidadeAtual;
        ciclistas[id].velocidadeAtual = 60;
      } else {
        ciclistas[id].velocidadeAnterior = ciclistas[id].velocidadeAtual;
        ciclistas[id].velocidadeAtual = 30;
      }
    } else if (ciclistas[id].velocidadeAtual == 60) {
      if(rand_range(1,100) < 40) {
        ciclistas[id].velocidadeAnterior = ciclistas[id].velocidadeAtual;
        ciclistas[id].velocidadeAtual = 30;
      } else {
        ciclistas[id].velocidadeAnterior = ciclistas[id].velocidadeAtual;
        ciclistas[id].velocidadeAtual = 60;
      }
    }
		/*Se o ciclista da frente estiver a 30km/h, então*/
    /*Se o ciclista estiver na ultima posição e encontrar um retardatario*/
    if ((int)fmod(ciclistas[id].distancia,d) == d-1) {
      if (pista[0][ciclistas[id].faixa] != -1 && ciclistas[pista[0][ciclistas[id].faixa]].velocidadeAtual == 30) {
				/*Tenta ultrapassar*/
        if (ciclistas[id].faixa != 9 && pista[(int)fmod(ciclistas[id].distancia,d)][ciclistas[id].faixa+1] == -1) {
            pista[(int)fmod(ciclistas[id].distancia,d)][ciclistas[id].faixa] = -1;
            pista[(int)fmod(ciclistas[id].distancia,d)][ciclistas[id].faixa+1] = id;
            ciclistas[id].faixa += 1;
        } else {
          ciclistas[id].velocidadeAtual = 30;
        }
      }
    }
    /*Todos os casos exceto o anterior*/
    else
		{
      if (pista[(int)fmod(ciclistas[id].distancia,d) + 1][ciclistas[id].faixa] != -1
      && ciclistas[pista[(int)fmod(ciclistas[id].distancia,d) + 1][ciclistas[id].faixa]].velocidadeAtual == 30)
			{
				if (ciclistas[id].velocidadeAtual >= 60) {
		      /*Tenta ultrapassar*/
		      if (ciclistas[id].faixa != 9 && pista[(int)fmod(ciclistas[id].distancia,d)][ciclistas[id].faixa+1] == -1) {
		          pista[(int)fmod(ciclistas[id].distancia,d)][ciclistas[id].faixa] = -1;
		          pista[(int)fmod(ciclistas[id].distancia,d)][ciclistas[id].faixa+1] = id;
		          ciclistas[id].faixa += 1;
					} else {
		        ciclistas[id].velocidadeAtual = 30;
		      }
		    }
      }
    }
	}
}
void troca_posicao (int id) {
	ciclistas[id].tf = ciclistas[id].tf + ms;
	if (pista[(int)fmod(ciclistas[id].distancia,d)][ciclistas[id].faixa] == id) {
		pista[(int)fmod(ciclistas[id].distancia,d)][ciclistas[id].faixa] = -1;
	}

	if (ciclistas[id].velocidadeAtual == 60 && ms == 60) {
		  ciclistas[id].pos_anterior = ciclistas[id].distancia;
      ciclistas[id].distancia = ciclistas[id].distancia + 1;
	} else if (ciclistas[id].velocidadeAtual == 30 && ms == 60) {
		  ciclistas[id].pos_anterior = ciclistas[id].distancia;
      ciclistas[id].distancia = ciclistas[id].distancia + 0.5;
	} else if (ciclistas[id].velocidadeAtual == 60 && ms == 20) {
		  ciclistas[id].pos_anterior = ciclistas[id].distancia;
      ciclistas[id].distancia = ciclistas[id].distancia + 0.3334;
	} else if (ciclistas[id].velocidadeAtual == 30 && ms == 20) {
		  ciclistas[id].pos_anterior = ciclistas[id].distancia;
      ciclistas[id].distancia = ciclistas[id].distancia + 0.1667;
	} else {
		ciclistas[id].pos_anterior = ciclistas[id].distancia;
		ciclistas[id].distancia = ciclistas[id].distancia + 0.5;
	}
  pista[(int)fmod(ciclistas[id].distancia,d)][ciclistas[id].faixa] = id;
}

void *task(void * id) {

  ts.tv_sec  = 0;
	ts.tv_nsec = ms * 10000000; // 1/100 s
  int *s = (int*) id;
  int posAnt,cmp, dist;
	if (*s == 0) {
		primeiro = ciclistas[*s];
	}

  while (1) {
		/*Cálculo de quanto vai andar*/
    pthread_mutex_lock(&sem3);
		if (ciclistas[*s].id == primeiro.id) {
			tempo = tempo + ms;
			if (debug) {
				printf("----------------%d ms -----------------\n", tempo);
				dump_pista();
			}
		}
		if (idEliminado != *s)
			calculo_velocidade(*s);
    pthread_mutex_unlock(&sem3);

		/*Cálculo de quanto vai andar*/
    pthread_mutex_lock(&sem4);
		if (idEliminado != *s)
			troca_posicao (*s);
    pthread_mutex_unlock(&sem4);


		ts.tv_nsec = 10000000 * ms;

    nanosleep(&ts,NULL);
    /*Verifica o último e o primeiro ciclista*/
    pthread_mutex_lock(&sem);
    if (num > 1) {

      /*Inicializa o ultimo e o primeiro*/
      if (ultimoVazio) {
        primeiro = ciclistas[*s];
        ultimo[0] = ciclistas[*s];
        ultimoVazio = 0;
        pos++;
      }
      /*Vê quem é o último*/
      if (ciclistas[*s].distancia < ultimo[0].distancia) {
        ultimo[pos] = ultimo[0];
        ultimo[0] = ciclistas[*s];
        pos++;
      }
      /*Vê quem é o primeiro*/
      if (ciclistas[*s].distancia > primeiro.distancia) {
        primeiro = ciclistas[*s];
      }
      if (ciclistas[*s].distancia == primeiro.distancia && ciclistas[*s].id != primeiro.id && ciclistas[*s].id != ultimo[0].id) {
        primeiro = ciclistas[*s];
      }
      if (pos > 1 && primeiro.id == ultimo[0].id) {
        primeiro = ultimo[1];
      }
    }
    pthread_mutex_unlock(&sem);
    pthread_barrier_wait(&barrier[altera]);
    pthread_mutex_lock(&sem1);
    /*Se for o último, verifica se foi eliminado*/
    if (ciclistas[*s].id == ultimo[0].id) {
      cmp = (int)fmod(ultimo[0].distancia,d);
      dist = (int)ultimo[0].distancia;

      if (rodada[ultimo[0].volta] == 0 && dist != 0 && cmp == 0) {
        rodada[ultimo[0].volta] = 1;
        if (ultimo[0].volta%2 == 0) {
          eliminado = 1;
          num--;
          idUltimo = ultimo[0].id;
					idEliminado = ultimo[0].id;
					ranking[indice_r] = ciclistas[*s];
					indice_r++;
					if (pista[(int)fmod(ciclistas[*s].distancia,d)][ciclistas[*s].faixa] == *s) {
						pista[(int)fmod(ciclistas[*s].distancia,d)][ciclistas[*s].faixa] = -1;
					}
        }
      }
			if (num > 5 && primeiroQuebrado == 1 && ciclistas[*s].id != 0 && ciclistas[*s].volta%6 == 0 && ciclistas[*s].id != ultimo[0].id) {
				if (rand_range(0, 100) < 5) {
					indice_q++;
					idQuebrado = ciclistas[*s].id;
					quebrado = 1;
					quebrou = 1;
					num--;
					primeiroQuebrado = 0;
				}
			}
    }
    posAnt = (int)ciclistas[*s].pos_anterior;
    cmp = (int)fmod(ciclistas[*s].distancia+1,d);
    dist = (int)ciclistas[*s].distancia;
    /*Acrescenta uma volta se a volta for par diferente de zero*/

    if (dist != 0 && posAnt != (int)ciclistas[*s].distancia && cmp == 0) {
			ciclistas[*s].volta++;
    }
    pthread_mutex_unlock(&sem1);
    pthread_barrier_wait(&barrier[altera]);

    /*Variavel para re-inicializar o ultimo e o primeiro*/
    ultimoVazio = 1;
    pos = 0;
		primeiroQuebrado = 1;
    pthread_barrier_wait(&barrier[altera]);
  }
  return NULL;
}

int main(int argc, char const *argv[]) {
  pthread_mutex_init(&sem, NULL);
  pthread_mutex_init(&sem1, NULL);
  pthread_mutex_init(&sem2, NULL);
  pthread_mutex_init(&sem3, NULL);
	pthread_mutex_init(&sem4, NULL);

	if (argc < 3) {
		printf("Numero invalido de argumentos\n");
		exit(1);
	}
	if(argc == 4 && !strcmp(argv[3],"b")) {
		debug = 1;
	}

	d = atoi(argv[1]);
	n = atoi(argv[2]);
  num = n;
  int i, j, k;
  int tamanho;
  int ids[n];
	ms = 60;
  srand(500);

	pista = malloc(d*sizeof(int *));
  for(i = 0; i < d; i++) {
    pista[i] = malloc(10*sizeof(int));
	}
  for(i = 0; i < d; i++) {
    for(int j = 0; j < 10; j++) {
      pista[i][j] = -1;
		}
	}
	tamanho = n*2;
  ciclista = malloc(n*sizeof(pthread_t));
  rodada = malloc(tamanho*sizeof(int));
  for (i = 0; i < tamanho; i++) {
    rodada[i] = 0;
  }

  ultimo = malloc(n*sizeof(Ciclistas));
  ciclistas = malloc(n*sizeof(Ciclistas));
	ranking = malloc(n*sizeof(Ciclistas));
	quebrados = malloc(n*sizeof(Ciclistas));
  for (i = 0; i < n; i++) {
    ciclistas[i] = init(0, 0, 0, i);
  }

	ocupa_pista();
  altera = 0;
  pthread_barrier_init(&barrier[altera], NULL, n+1);

  for ( i = 0; i < n; i++) {
    ids[i] = i;
    if (pthread_create(&ciclista[i], NULL, task, (void*)&ids[i])) {
      printf("\nERROR creating thread %d\n", i);
      exit(1);
    }
  }

	k = 0;
  j = 0;
  while (num > 1) { //resta um
    pthread_barrier_wait(&barrier[altera]);
    pthread_barrier_wait(&barrier[altera]);
    pthread_barrier_init(&barrier[!altera], NULL, num+1);
    pthread_barrier_wait(&barrier[altera]);
    /*Eliminação*/
    pthread_mutex_lock(&sem2);
		if (quebrado) {
			k = idQuebrado;
			printf("Ciclista %d QUEBROU\n", k);
      pthread_cancel(ciclista[k]);
      if (pthread_join(ciclista[k], NULL)) {
        printf("\nERROR joining thread %d\n", k);
        exit(1);
      }
      quebrado = 0;
		}
    if (eliminado) {
      j = idUltimo;
      pthread_cancel(ciclista[j]);
      if (pthread_join(ciclista[j], NULL)) {
        printf("\nERROR joining thread %d\n", j);
        exit(1);
      }
      eliminado = 0;
    }
    pthread_mutex_unlock(&sem2);
    altera = !altera;
  }

  j = primeiro.id;
  pthread_cancel(ciclista[j]);
  if (pthread_join(ciclista[j], NULL)) {
    printf("\nERROR joining thread %d\n", j);
    exit(1);
  }
	ranking[indice_r] = ciclistas[j];
	int finais = indice_r;
	while (indice_r >= 0) {
		printf("Ciclista %d -- Ranking: %d -- Tempo Final %d\n", ranking[indice_r].id, finais-indice_r+1, ranking[indice_r].tf);
		indice_r--;
	}

	while (quebrou && indice_q >= 0) {
		printf("Ciclista %d -- Quebrado -- Volta: %d\n", quebrados[indice_q].id, quebrados[indice_q].volta);
		indice_q--;
	}

	free(ultimo);
	free(ciclistas);
	free(ranking);
	free(quebrados);
	free(rodada);
	for(i = 0; i < d; i++) {
		free(pista[i]);
	}
	free(pista);

  pthread_barrier_destroy(&barrier[altera]);
  pthread_barrier_destroy(&barrier[!altera]);
  return 0;
}
