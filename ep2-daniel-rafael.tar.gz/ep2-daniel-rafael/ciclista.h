#ifndef CICLISTA_H
#define CICLISTA_H


struct CICLISTA
{
	int Vo,quebrou,volta,id, velocidadeAnterior, velocidadeAtual, faixa, eliminado, noventa, tf;
	float distancia, pos_anterior;
};
typedef struct CICLISTA Ciclistas;

Ciclistas init(int Vo, int quebrou, int volta, int id);

#endif
