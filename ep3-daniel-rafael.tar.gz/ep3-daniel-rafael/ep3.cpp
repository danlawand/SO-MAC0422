#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
#include <ctime>
#include <cmath>
#include "diretorio.hpp"
#include "arquivo.hpp"
using namespace std;

int FAT[25000];
bool bitmap[25000];
vector<diretorio> dir;
vector<arquivo> arq;
long long int tam = 0;
long long int ini = 0;
long long int END;
fstream file;

void comandos(string token[])
{
	
	if(!token[0].compare("mount"))
	{
		file.open(token[1], ios::in | ios::out | std::fstream::in);
		if(file.fail())
		{ 

			cout << "arquivo " << token[1] << " inexiste" << endl;
			cout << "criando arquivo " << token[1] << endl;
			file.open(token[1], ios::out);
			for(int i = 0; i < 25000; i++)
			{
				FAT[i] = -1;
				file << FAT[i]<<" ";

			}
			file << endl;
			bitmap[0] = false;
			file << bitmap[0]<<" ";
			for(int i = 1; i < 25000; i++)
			{
				bitmap[i] = true;
				file << bitmap[i]<<" ";
			}
			file << endl;
			ini = file.tellp();
			long int temp = time(NULL);
			diretorio raiz("/",temp,temp,temp);
			dir.push_back(raiz);
			file << dir[0].nome << "|" << dir[0].criado << "|" << dir[0].modificado << "|" << dir[0].acessado << endl;
			file.flush();
			END = file.tellp();
			//cout << tam << endl;
			//leitura.open(token[1], ios::in);
		}
		else
		{
			
			cout << "arquivo " << token[1] << " aberto" << endl;
			
			for(int i = 0; i < 25000; i++)
			{
				file >> FAT[i];
				//cout << FAT[i] << " ";
			}
			//cout << endl;
			for(int i = 0; i < 25000; i++)
			{
				file >> bitmap[i];
				//cout << bitmap[i] << " ";
			}
			ini = file.tellg() + (streampos)2;
			file.seekg(ini);
			string line;
			while(getline(file,line))
			{
				string info[6];
				istringstream iss(line);
				if(line[0] == '/')
				{
					for(int i = 0; i < 4 && getline(iss,info[i],'|'); i++);
					diretorio x(info[0],stoi(info[1]),stoi(info[2]),stoi(info[3]));
					dir.push_back(x);
					cout << dir.back().nome << "|" << dir.back().criado << "|"<< dir.back().modificado << "|" << dir.back().acessado<<endl;
				}
				else
				{
					for(int i = 0; i < 6 && getline(iss,info[i],'|'); i++);
					arquivo x(info[0],info[1],stoi(info[2]),stoi(info[3]),stoi(info[4]),stoi(info[5]));
					arq.push_back(x);
					cout << arq.back().nome << "|"<<arq.back().conteudo<< "|"<< arq.back().tamanho <<"|" << arq.back().criado << "|"<< arq.back().modificado << "|" << arq.back().acessado<<endl;				
				}
			}
			//cout << endl;
			// FALTA CRIAR A PARTE ONDE LEMOS O CENTEUDO INTEIRO DO ARQUIVO
			END = file.tellp();
		}
	}
	else if(!token[0].compare("cp"))
	{
		fstream x(token[1], ios::out);
		if(x.fail()) {
			cout << "Falha ao abrir o arquivo" << endl;
			return;
		}
		string conteudo,aux;
		getline(x,conteudo);
		aux = conteudo;		
		while(!x.eof())
		{
			getline(x,conteudo);
			aux += conteudo;
		}
		long int tempo = time(NULL);
		arquivo a(token[1],aux,x.tellp(),tempo,tempo,tempo);
		arq.push_back(a);
		string line;
		string nome;
		while(getline(file,line))
		{
			istringstream iss(line);
			getline(iss,nome,'|');
			if(nome.compare(token[2]) == 0) break;
		}
		int i;
		for(i = 0; i < dir.size()-1; i++)
		{
			if(nome.compare(dir.at(i).nome)==0) break;
		}
		diretorio y = dir.at(i);
		//file.seekp(ini + y.nome.length() + (int)3*(log10(y.criado) + 1) + 3);
		file << a.nome <<"|"<<a.conteudo<<"|"<<a.tamanho<<"|"<<a.criado<<"|"<<a.modificado<<"|"<<a.acessado<<endl;
	}
	else if(!token[0].compare("mkdir") && file.is_open())
	{
		 
		
		diretorio novo(token[1],time(NULL),time(NULL),time(NULL));
		dir.push_back(novo);
		file << dir.back().nome << "|" << dir.back().criado << "|"<< dir.back().modificado << "|" << dir.back().acessado<<endl;
	
	}
	else if(!token[0].compare("rmdir") && file.is_open())
	{
		
	}
	else if(!token[0].compare("cat") && file.is_open())
	{
		for(int i = 0; i < arq.size(); i++)
		{
			
			if(!token[1].compare(arq.at(i).nome))
			{
			 	cout << arq.at(i).conteudo << endl;
			 	return;
			}
		}
		
	}
	else if(!token[0].compare("touch") && file.is_open())
	{
		
	}
	else if(!token[0].compare("rm") && file.is_open())
	{
		
	}
	else if(!token[0].compare("ls") && file.is_open())
	{
		
	}
	else if(!token[0].compare("find") && file.is_open())
	{
		
	}
	else if(!token[0].compare("df") && file.is_open())
	{
		
	}
	else if(!token[0].compare("unmount") && file.is_open())
	{

		file.close();
	}
	else
		cout << "comando nao reconehcido" << endl;
	
}


int main()
{
	string line;
	while(cout << "[ep3]: " && getline(cin,line))
	{
		string token[3];
		istringstream iss(line);
		for(int i = 0; i < 3 && getline(iss,token[i],' '); i++);
		comandos(token);
		if(!token[0].compare("sai"))
		{
			//fazer CP
			break;
		}

	}
	return 0;
}