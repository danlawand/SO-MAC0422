#ifndef DIR_H
#define DIR_H

class diretorio
{
	public:
		std::string nome;
		long int criado;
		long int modificado;
		long int acessado;
		diretorio()
		{
			nome = " ";
			criado = 0;
			modificado = 0;
			acessado = 0;
		}
		diretorio(std::string nome, long int criado, long int modificado, long int acessado)
		{
			this->nome = nome;
			this->criado = criado;
			this->modificado = modificado;
			this->acessado = acessado;
		}
};


#endif