#ifndef ARQ_H
#define ARQ_H

class arquivo
{
	public:
		std::string nome;
		std::string conteudo;
		long int tamanho;
		long int criado;
		long int modificado;
		long int acessado;
		arquivo()
		{
			this->nome = " ";
			this->conteudo = " ";
			this->tamanho = 0;
			this->criado = 0;
			this->modificado = 0;
			this->acessado = 0;
		}
		arquivo(std::string nome, std::string conteudo,long int tamanho, long int criado, long int modificado, long int acessado)
		{
			this->nome = nome;
			this->conteudo = conteudo;
			this->tamanho = tamanho;
			this->criado = criado;
			this->modificado = modificado;
			this->acessado = acessado;
		}
};

#endif